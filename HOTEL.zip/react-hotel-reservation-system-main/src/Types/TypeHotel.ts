declare global {
    type TypeHotel = {
        id: string;
        hotel_name: string;
    };
}

export {};
